package logging;

public class LoggerTest {

	public static void main(String[] args) {

		MyLogger myLogger = new MyLogger();
		
		myLogger.log("test");

	}

}
